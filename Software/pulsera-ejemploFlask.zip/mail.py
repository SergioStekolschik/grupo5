#! /usr/bin/python

import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email.mime.image import MIMEImage
from email import encoders

def mail(destinatario,msg,attachment,ruta_adjunto,nombre_adjunto):
	# Iniciamos los parametros del script
	remitente = "Evento presentacion <mmmmmmmmmmmmmmmmmmmm@gmail.com>" 
	asunto = "Retiro de consumiciones" 

	# Creamos el objeto mensaje
	mensaje = MIMEMultipart()

	# Establecemos los atributos del mensaje
	mensaje['From'] = remitente
	mensaje['To'] = destinatario
	mensaje['Subject'] = asunto

	# Agregamos el cuerpo del mensaje como objeto MIME de tipo texto
	mensaje.attach(MIMEText(msg, 'html'))

	if (attachment != "" ) :
		fp = open(attachment, 'rb')
		img = MIMEImage(fp.read())
		fp.close()
		img.add_header('Content-ID', '<{}>'.format(attachment))
		mensaje.attach(img)
	
	if (ruta_adjunto != "" and archivo_adjunto != "" ) :
		# Abrimos el archivo que vamos a adjuntar
		archivo_adjunto = open(ruta_adjunto, 'rb')
		# Creamos un objeto MIME base
		adjunto_MIME = MIMEBase('application', 'octet-stream')
		# Y le cargamos el archivo adjunto
		adjunto_MIME.set_payload((archivo_adjunto).read())
		# Codificamos el objeto en BASE64
		encoders.encode_base64(adjunto_MIME)
		# Agregamos una cabecera al objeto
		adjunto_MIME.add_header('Content-Disposition', "attachment; filename= %s" % nombre_adjunto)
		# Y finalmente lo agregamos al mensaje
		mensaje.attach(adjunto_MIME)
		
	try:
		# Creamos la conexion con el servidor
		sesion_smtp = smtplib.SMTP('smtp.gmail.com', 587) 
		# Ciframos la conexion
		sesion_smtp.starttls()
		# Iniciamos sesion en el servidor
		sesion_smtp.login('mmmmmmmmmmmmmmmmmmmm@gmail.com','mmmmmmmmmmmmmmmm)
		# Convertimos el objeto mensaje a texto
		texto = mensaje.as_string()
		# Enviamos el mensaje
		sesion_smtp.sendmail(remitente, destinatario, texto)
		# Cerramos la conexion
		sesion_smtp.quit()	
		print ("Correo enviado")

	except: 
		print ("Error: el mensaje no pudo enviarse. Compruebe que sendmail se encuentra instalado en su sistema")
		