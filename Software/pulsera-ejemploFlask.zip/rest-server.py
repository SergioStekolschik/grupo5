#!flask/bin/python
from flask import Flask, jsonify, abort, request, make_response, url_for
import mail

app = Flask(__name__, static_url_path = "")
    
@app.errorhandler(400)
def not_found(error):
    return make_response(jsonify( { 'error': 'Bad request' } ), 400)

@app.errorhandler(404)
def not_found(error):
    return make_response(jsonify( { 'error': 'Not found' } ), 404)

# Tarjeta: 00CCB456	
# llave: 40D5B879

tasks = [
    {
        'id': u'40D5B879',
    'nombre': u'rrrrrr', 
    'apellido': u'dddddddd', 
    'correo': u'rrrrrr.dddddddd@gmail.com', 
    'cantidad': 3,
    'done': False
    },
    {
        'id': u'00CCB456',
    'nombre': u'xxxxx', 
    'apellido': u'yyyyyyy', 
    'correo': u'xxxxx.yyyyyyy@gmail.com', 
    'cantidad': 3,
    'done': False
    }
]

def make_public_task(task):
    new_task = {}
    for field in task:
        if field == 'id':
            new_task['uri'] = url_for('get_task', task_id = task['id'], _external = True)
        else:
            new_task[field] = task[field]
    return new_task

@app.route('/', methods = ['GET'])
def test_url():
    return "Test OK"

@app.route('/todo/api/v1.0/tasks', methods = ['GET'])
def get_tasks():
    return jsonify( { 'tasks': map(make_public_task, tasks) } )

@app.route('/todo/api/v1.0/tasks/<int:task_id>', methods = ['GET'])
def get_task(task_id):
    task = filter(lambda t: t['id'] == task_id, tasks)
    print task

    if len(task) == 0:
        abort(404)
    return jsonify( { 'task': make_public_task(task[0]) } )

@app.route('/todo/api/v1.0/tasks/<string:task_id>', methods = ['PUT'])
def update_task(task_id):

    task = filter(lambda t: t['id'] == task_id, tasks)
    print task

    if len(task) == 0:
        abort(404)
    print "recibido" 
    print request.json
    if not request.json:
        abort(400)
    if 'cliente' in request.json and type(request.json['cliente']) is not unicode:
        abort(400)
    if 'done' in request.json and type(request.json['done']) is not bool:
        abort(400)
   
    respuesta = u'No'
    print respuesta
    if task[0]['cantidad'] > 0 :
        task[0]['cantidad'] =  task[0]['cantidad'] - 1

        template = """
            <head>
                <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
                <title>Evento presentaci&oacute;n</title>
                <style type="text/css" media="screen">
                    h1 {
                        color: black;
                        font-family: Verdana;
                        font-size: 300%;
                    }
                </style>
            </head>
            <body>
                <h1>Evento presentaci&oacute;n</h1><br/> <br/> 
                <h2>%s</h2><br/><br/> 
                <h3>Te quedan %s consumisiones</h3><br/> <br/> 
                <br/> 
                <br/> 
                <img src="cid:logo-min.png">
                <br/> 
            </body>
        """

        msg = """
            <head>
                <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
                <title>Evento presentaci&oacute;n</title>
                <style type="text/css" media="screen">
                    h1 {
                        color: black;
                        font-family: Verdana;
                        font-size: 300%;
                    }
                </style>
            </head>
            <body>
                <h1>Evento presentaci&oacute;n</h1><br/> <br/> 
                <h2>
        """
        msg += task[0]['nombre']
        msg += """
                </h2><br/><br/> 
                <h3>Te quedan 
              """
        msg += str(task[0]['cantidad'])
        msg += """
                consumisiones</h3><br/> <br/> 
                <br/> 
                <br/> 
                <img src="cid:logo-min.png">
                <br/> 
            </body>
        """ 

        respuesta = u'Si'
        print respuesta
        mail.mail(task[0]['correo'],msg,'logo-min.png','','')
            
    return jsonify( { 'result': respuesta } )
        
if __name__ == '__main__':
    app.run(debug = True)
